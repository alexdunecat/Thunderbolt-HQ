/* Схема боя на карте: ракеты, трассеры, лучи, бомбы, ловушки и взрывы. Рисует каждый клиент сам по карточкам чата,
   поэтому сокет не нужен: пуск Fox Two! или ЗРК — ракета уходит к цели и висит в воздухе меткой с пунктиром до залпа;
   залп конца раунда — ракеты доходят: попадание взрывается, промах проходит мимо (с ловушками, если цель делала Break!).
   Пушка, НУР и лазер бьют сразу; линия EMRG и рельсотрон — луч; ковровая бомбардировка — бомбы; удар по площади — взрывы в зонах;
   рисунок выстрела по стрелку: танк и БМП бьют снарядом (вспышка у ствола, снаряд летит в залпе), артиллерия и главный калибр
   корабля — навесом, артустановки кораблей и пушка танка — снарядами, зенитки, ЗАК и самолёты — очередью трассеров;
   сбитая машина — большой взрыв с дымом. Выключается у себя в настройках («Анимация ракет и попаданий»).
   Невидимое для игрока (скрытый токен, вне обзора) не рисуется: схема не выдаёт засаду. */
import { SYSTEM_ID } from "./config.mjs";
import { resolveActor } from "./utils.mjs";
import { isFlying, altOf, hasRule, WATER } from "./scene.mjs";
import { playCallouts, callout } from "./callouts.mjs";
import { enginesOf, contrailLines, CONTRAIL } from "./contrails.mjs";

/* ---------- план: что показать по карточке (чистая часть, тесты) ---------- */

const RAIL_TOTAL = (c, r) => c.total + (r.gnd ? c.depShift ?? 0 : 0);

/**
 * Что нарисовать по карточке. compute — computeCard из rolls.mjs (итог и успех броска).
 * Возвращает список шагов: { kind, from, to, hit, ... } (from, to — UUID актёров) или [].
 */
/** Зенитные стволы: очередь трассеров, а не снаряды. */
const AA_GUN = /зенит|ЗАК|CIWS|автомат|Кортик|Шилка|Тунгуска/i;

/**
 * Рисунок мгновенного выстрела по карточке и стрелку w ({ type, kind, grp } или null):
 * beam (лазер, луч), rail (рельсотрон), rockets (НУР), cannon (снаряды: танк, артустановка корабля), guns (очередь).
 */
export function shotStyle(card, w) {
  const label = card?.label ?? "";
  if (/рельс|rail ?gun/i.test(label)) return "rail";
  if (/лазер|луч/i.test(label)) return "beam";
  if (/НУР/.test(label)) return "rockets";
  if (w?.type === "npc" && w.kind === "ship") return /^Огонь:/.test(label) && !AA_GUN.test(label) ? "cannon" : "guns";
  if (w?.type === "npc" && w.kind === "ground") return w.grp === "armor" ? "cannon" : "guns";
  return "guns";
}
const whoOf = uuid => { try { const a = resolveActor(uuid); return a ? { type: a.type, kind: a.system?.kind, grp: a.system?.grp } : null; } catch { return null; } };

export function planOf(card, compute = c => c, who = whoOf) {
  if (!card) return [];
  if (card.type === "break" && card.actorUuid) return [{ kind: "flares", at: card.actorUuid }];
  if (card.type === "strike") return card.zones?.length ? [{ kind: "blast", zones: card.zones }] : [];
  if (card.type === "volley") {
    const out = [];
    for (const r of card.targets ?? []) {
      if (r.missing || !r.uuid) continue;
      out.push({ kind: "impact", to: r.uuid, from: r.shooterUuids ?? (r.sourceUuid ? [r.sourceUuid] : []), count: r.count ?? 1,
        hit: !!r.hit && !r.cobra, ship: !!r.ship, bomb: !!r.bomb, broke: !!r.broke || !!r.cobra, prox: !!r.prox, ...(r.fx && Object.keys(r.fx).length ? { fx: r.fx } : {}) });
    }
    for (const l of card.lost ?? []) out.push({ kind: "lost", name: l.name });
    return out;
  }
  if (card.type === "rail" && card.actorUuid) {
    const c = compute(card), rows = (card.line ?? []).map(r => ({ to: r.uuid, hit: RAIL_TOTAL(c, r) >= r.vs }));
    const kind = card.label === "Ковровая бомбардировка" ? "carpet" : card.label === "Бортовые орудия" ? "gunship" : "beam";
    if (kind === "gunship") return rows.map(r => ({ kind, from: card.actorUuid, ...r }));
    // линия EMRG: луч до края карты, даже если на линии никого
    return rows.length || card.end ? [{ kind, from: card.actorUuid, rows, ...(card.end ? { end: card.end } : {}) }] : [];
  }
  if (!card.attack || !card.actorUuid || !card.targetUuid) return [];
  const all = [card.targetUuid, ...(card.salvo ?? []).map(s => s.uuid)];
  if (card.instant) {
    const c = compute(card), known = card.dc !== null && card.dc !== undefined;
    const w = who(card.actorUuid), style = shotStyle(card, w);
    const hit = known ? !!c.success : null;
    if (style === "beam" || style === "rail") return [{ kind: "beam", from: card.actorUuid, rows: [{ to: card.targetUuid, hit }], ...(style === "rail" ? { rail: true } : {}) }];
    if (style === "cannon") return [{ kind: "cannon", from: card.actorUuid, to: card.targetUuid, hit, n: w?.kind === "ship" ? 2 : 1, big: w?.kind === "ship" }];
    return [{ kind: style, from: card.actorUuid, to: card.targetUuid, hit, n: style === "rockets" ? 4 : 6 }];
  }
  // ракета (Fox Two!, ЗРК, корабль): в бою висит до залпа, вне боя долетает и рвётся; снаряд танка и навес артиллерии — вспышка у ствола
  return all.map(to => ({ kind: "launch", from: card.actorUuid, to, bomb: !!card.bomb, wait: !!card.combatKey, ...(card.fx ? { fx: card.fx } : {}) }));
}

/** Ракета ещё в воздухе: карточка пуска, которую залп не посчитал. */
export const inAir = c => !!(c?.delayed && c.combatKey && c.targetUuid && !c.resolved && !c.dmgApplied && !c.lost);
/** Висит ли в воздухе меткой: снаряд и навес до залпа не рисуются, они летят в залпе. */
const marked = c => inAir(c) && !c.fx;

/* ---------- настройки и хуки ---------- */

const on = () => { try { return game.settings.get(SYSTEM_ID, "fxOn") !== false; } catch { return true; } };

/** Повреждённая машина на карте: метка Doom — горит, метка Structure — дымит, иначе null. */
export function burnOf(actor) {
  const m = actor?.system?.markers;
  if (!m || !["pilot", "npc"].includes(actor.type)) return null;
  return m.doom ? "fire" : m.structure ? "smoke" : null;
}

/** Тянет ли машина инверсионный след: летит на Высокой или в стратосфере. */
export const trailOf = (token, actor = token?.actor) => isFlying(actor) && ["high", "strat"].includes(altOf(token, actor));
/** След по земле и воде: корабль на ходу оставляет кильватер, наземная техника поднимает пыль (на Севере снежную).
    Сухопутный линкор («Тарпан») на суше оставляет колею гусениц, на воде (terrain — местность под ним) — кильватер.
    Летающие корабли, подлодка под водой и объекты следа не оставляют. */
export function groundTrailOf(actor, terrain = null) {
  if (actor?.type !== "npc" || isFlying(actor)) return null;
  const s = actor.system;
  if (s.kind === "ship" && hasRule(actor, "landship")) return terrain && WATER.includes(terrain) ? "wake" : "tracks";
  if (s.kind === "ship") return actor.getFlag?.(SYSTEM_ID, "unit")?.sub ? null : "wake";
  if (s.kind === "ground" && s.grp !== "obj" && s.grp !== "boss") return "dust";
  return null;
}
/** Идёт ли машина на форсаже: летит на своей Max Speed. */
export const burnerOf = actor => isFlying(actor) && Number(actor.system?.maxSpeed) > 0 && Number(actor.system?.speed) >= Number(actor.system.maxSpeed);

export function registerFx() {
  game.settings.register(SYSTEM_ID, "fxOn", {
    name: "Анимация ракет и попаданий", hint: "Схема боя на карте: ракеты с дымным следом, трассеры, лучи, ловушки, взрывы и сбитые машины. Только у себя.",
    scope: "client", config: true, type: Boolean, default: true, onChange: v => { if (!v) clearAll(); else syncAir(); }
  });
  game.settings.register(SYSTEM_ID, "fxBurn", {
    name: "Дым и огонь у повреждённых", hint: "Машина с меткой Structure тянет за собой дымный след, с меткой Doom горит. Только у себя, вместе с анимацией.",
    scope: "client", config: true, type: Boolean, default: true
  });
  game.settings.register(SYSTEM_ID, "fxTrail", {
    name: "Инверсионные следы", hint: "Машины на Высокой и в стратосфере тянут белый след от своих двигателей: у истребителя одна-две тонкие нитки, которые быстро сливаются и тают, у тяжёлых и транспортных — широкие полосы от каждой гондолы, которые держатся долго. Поршневые и вертолёты следа не тянут. Только у себя, вместе с анимацией.",
    scope: "client", config: true, type: Boolean, default: true, onChange: () => trailAt.clear()
  });
  game.settings.register(SYSTEM_ID, "fxWake", {
    name: "Кильватер, пыль и колея", hint: "Корабль на ходу оставляет белый расходящийся след на воде, наземная техника поднимает пыль (на Севере снег), сухопутный линкор оставляет колею гусениц. Только у себя, вместе с анимацией.",
    scope: "client", config: true, type: Boolean, default: true
  });
  game.settings.register(SYSTEM_ID, "fxBurner", {
    name: "Форсаж", hint: "У машины на своей максимальной скорости при движении из сопла бьёт короткое пламя. Только у себя, вместе с анимацией.",
    scope: "client", config: true, type: Boolean, default: true
  });
  game.settings.register(SYSTEM_ID, "fxVapor", {
    name: "Пар и вихри", hint: "Машина, которая разгоняется до своей максимальной Speed, на миг одевается конусом пара, а по карте расходится хлопок. На Break! с концов крыльев срываются белые нити вихрей. Только у себя, вместе с анимацией.",
    scope: "client", config: true, type: Boolean, default: true
  });
  game.settings.register(SYSTEM_ID, "fxCraters", {
    name: "Воронки после ударов", hint: "Бомбы, ракеты и снаряды по наземным целям оставляют на земле воронки и подпалины, которые тают за три раунда (вне боя — за пару минут). На воде воронок нет. Только у себя, вместе с анимацией.",
    scope: "client", config: true, type: Boolean, default: true, onChange: () => drawScars()
  });
  // разгон до максимальной Speed: конус пара и хлопок (изменение видят все клиенты, сокет не нужен)
  Hooks.on("updateActor", (actor, change, options) => { if (!options?.tbUndo) onSpeed(actor, change); });
  Hooks.on("updateActorDelta", (delta, change, options) => { if (!options?.tbUndo) onSpeed(delta.parent?.actor, change); });
  Hooks.on("updateCombat", () => drawScars());
  Hooks.on("deleteCombat", () => { for (let i = scars.length - 1; i >= 0; i--) if (scars[i].round != null) scars.splice(i, 1); drawScars(); });
  // unref: в проверках под Node таймер не держит процесс
  Hooks.once("ready", () => setInterval(() => {
    try { burnTick(); } catch (err) { console.warn(`${SYSTEM_ID} | дым`, err); }
    try { trailTick(); } catch (err) { console.warn(`${SYSTEM_ID} | след`, err); }
  }, BURN_MS)?.unref?.());
  Hooks.on("createChatMessage", (m, options) => { if (!options?.tbUndo) chuteFire(m); });
  Hooks.on("createChatMessage", (m, options) => { if (!options?.tbUndo) onCard(m).catch(err => { console.warn(`${SYSTEM_ID} | анимация`, err); report(`ошибка: ${err?.message ?? err}`); }); });
  // отчёты игроков ведущему: почему у них не нарисовалось (консоль игрока ведущему не видна)
  Hooks.once("ready", () => game.socket?.on(CHANNEL, msg => {
    if (msg?.type !== "fxReport" || !game.user.isGM || !game.users.activeGM?.isSelf) return;
    const k = `${msg.user}|${msg.reason}`;
    if (heard.has(k)) return;
    heard.add(k);
    console.warn(`${SYSTEM_ID} | анимация у игрока «${msg.user}»: ${msg.reason}`);
    ui.notifications.warn(`Анимация у игрока «${msg.user}»: ${msg.reason}`);
  }));
  for (const ev of ["updateChatMessage", "deleteChatMessage"]) Hooks.on(ev, () => syncSoon());
  Hooks.on("updateCombat", () => syncSoon());
  Hooks.on("deleteCombat", () => syncSoon());
  Hooks.on("canvasReady", () => { clearAll(); trailAt.clear(); scars.length = 0; scarGfx = null; syncSoon(); });
  Hooks.on("canvasTearDown", () => { clearAll(); scars.length = 0; scarGfx = null; });
  Hooks.on("createActiveEffect", (effect, options) => {
    if (options?.tbUndo || !effect.statuses?.has?.(CONFIG.specialStatusEffects.DEFEATED)) return;
    const a = effect.parent;
    for (const t of a?.isToken ? [a.token?.object] : a?.getActiveTokens?.() ?? []) if (t && seen(t)) downed(t);
  });
}

const CHANNEL = `system.${SYSTEM_ID}`;
const sent = new Set(), heard = new Set();
/** Игрок: сказать ведущему (раз за сессию на причину), почему анимация не нарисовалась. */
function report(reason) {
  if (game.user?.isGM || sent.has(reason)) return;
  sent.add(reason);
  try { game.socket?.emit(CHANNEL, { type: "fxReport", user: game.user?.name ?? "?", reason }); } catch { /* без связи — только консоль */ }
}

async function onCard(message) {
  const card = message.getFlag?.(SYSTEM_ID, "card");
  if (!card) return;
  // свой выстрел: машина разворачивается на цель (автокурс), ракета уходит чуть позже
  if (card.attack && card.actorUuid && message.isAuthor) {
    const first = card.targetUuid ?? card.line?.[0]?.uuid;
    const me = tokenFor(card.actorUuid), t = first ? tokenFor(first) : null;
    if (me && t) { const { faceToken } = await import("./rotate.mjs"); faceToken(me, t).catch(() => null); }
  }
  if (!on()) return report("анимация выключена у себя в настройках («Анимация ракет и попаданий»)");
  if (!canvas?.ready) return report("карта не открыта");
  const { computeCard } = await import("./dice/rolls.mjs");
  const plan = planOf(card, computeCard);
  if (!plan.length) return;
  // у игрока: цель не нашлась на открытой сцене или не видна — сказать ведущему, чтобы было видно, почему пусто
  if (!game.user.isGM) {
    const uuid = plan[0].to ?? plan[0].at ?? plan[0].rows?.[0]?.to ?? null, t = uuid ? tokenFor(uuid) : null;
    if (uuid && !t) report(resolveActor(uuid) ? "цель не на открытой сцене (игрок смотрит другую сцену?)" : "не удалось найти машину по карточке");
    else if (t && !seen(t)) report(`токен «${t.name}» не виден игроку (скрыт: ${!!t.document.hidden}, зрение токенов на сцене: ${!!canvas.visibility?.tokenVision})`);
  }
  playPlan(plan, message, card.type === "volley");
  // HIT / MISS над целью, когда выстрел долетает
  playCallouts(plan);
}

/** Очередь аса по куполу (parachute.mjs): трассеры от стрелка к точке купола. */
function chuteFire(message) {
  const f = message.getFlag?.(SYSTEM_ID, "chuteFire");
  if (!f || !on() || !canvas?.ready) return;
  const t = tokenFor(f.from);
  if (!t || !seen(t)) return;
  const at = { x: f.x, y: f.y };
  guns(P(t)(), () => at, { hit: !!f.hit, n: 8 });
}

/** Показать план (planOf) на карте: залп сначала снимает висящие ракеты, чтобы они долетели от своих меток. */
export function playPlan(plan, message = null, volley = false) {
  if (!on() || !canvas?.ready) return;
  if (volley) syncAir();
  plan.forEach((step, i) => run(step, message, i));
}

/* ---------- токены и точки ---------- */

function tokenFor(uuid) {
  const a = resolveActor(uuid);
  if (!a || !canvas?.ready) return null;
  const t = a.isToken ? a.token?.object : a.getActiveTokens?.()[0];
  return t && !t.destroyed && t.document?.parent === canvas.scene ? t : null;
}
/** Игрок видит токен: не скрыт и в обзоре. */
const seen = t => game.user.isGM || (!t.document.hidden && (t.visible !== false || !canvas.visibility?.tokenVision));
const P = t => () => (!t || t.destroyed ? null : { x: t.center.x, y: t.center.y });
/** Угол от точки a на точку b (b нет — 0). */
const toward = (a, b) => (b ? Math.atan2(b.y - a.y, b.x - a.x) : 0);
const gs = () => canvas.grid?.size ?? 100;
const lerp = (a, b, k) => ({ x: a.x + (b.x - a.x) * k, y: a.y + (b.y - a.y) * k });
const dist = (a, b) => Math.hypot(b.x - a.x, b.y - a.y);
const rnd = (a, b) => a + Math.random() * (b - a);
/** Откуда летит: невидимый стрелок — точка рядом с целью со случайной стороны. */
function origin(from, to) {
  if (from && seen(from)) return P(from)();
  const p = P(to)(), a = rnd(0, Math.PI * 2);
  return { x: p.x + Math.cos(a) * gs() * 0.9, y: p.y + Math.sin(a) * gs() * 0.9 };
}
const ours = uuid => { const a = resolveActor(uuid); return a?.type === "pilot" || ["ally", "player"].includes(a?.system?.side); };

/* ---------- шаги ---------- */

function run(step, message, i) {
  const k = step.kind;
  if (k === "flares") { const t = tokenFor(step.at); if (t && seen(t)) { flares(P(t)(), t.document.rotation); if (vaporOn()) vortices(t); } return; }
  if (k === "blast") return blastZones(step.zones);
  if (k === "lost") return null;
  if (k === "impact") return impact(step);
  const from = tokenFor(step.from);
  if (k === "carpet" || k === "beam") {
    if (!from) return;
    const a = P(from)();
    if (k === "beam" && step.end) {
      const [j, r] = String(step.end).split(",").map(Number), size = gs();
      const tl = canvas.grid.getTopLeftPoint?.({ i: r, j }) ?? { x: j * size, y: r * size };
      const e = { x: tl.x + size / 2, y: tl.y + size / 2 }, len = dist(a, e) || 1;
      // луч до дальнего края последней зоны
      const far = { x: e.x + (e.x - a.x) / len * size / 2, y: e.y + (e.y - a.y) / len * size / 2 };
      if (seen(from)) { beam(a, far, { color: 0x9fe8ff, delay: 250, width: 0.12, life: 800 }); later(250, () => { boom(a, 0.05); sparks(a, 7, 0.06); }); }
      step.rows.forEach((x, n) => {
        const t = tokenFor(x.to);
        if (t && seen(t) && x.hit) later(300 + n * 40, () => { const p = P(t)(); boom(p, 0.12); if (onGround(t)) scar(p, 0.14); });
      });
      return;
    }
    step.rows.forEach((r, j) => {
      const t = tokenFor(r.to);
      if (!t || !seen(t)) return;
      if (k === "carpet") return bomb(a, P(t), { hit: r.hit, delay: 120 + j * 160, scar: onGround(t) });
      if (step.rail && seen(from)) later(250, () => { boom(a, 0.05); sparks(a, 6, 0.06); });
      beam(seen(from) ? a : origin(null, t), P(t)(), step.rail ? { color: 0x9fe8ff, delay: 250 + j * 40, width: 0.11, life: 700 } : { color: 0x9fe8ff, delay: 250 + j * 40 });
      if (r.hit) later(320 + j * 40, () => { const p = P(t)(); boom(p, 0.11); if (step.rail && onGround(t)) scar(p, 0.13); });
      else if (r.hit === null) later(320, () => sparks(P(t)()));
    });
    return;
  }
  const to = tokenFor(step.to);
  if (!to || !seen(to)) return;
  const a = origin(from, to), gnd = onGround(to);
  if (k === "guns" || k === "rockets") return guns(a, P(to), { hit: step.hit, n: step.n, rockets: k === "rockets", delay: 250, scar: gnd && k === "rockets" });
  if (k === "cannon") {
    for (let n = 0; n < step.n; n++) shell(a, P(to), { hit: step.hit, delay: 250 + n * 220, size: step.big ? 0.11 : 0.08, flash: seen(from ?? to) && !!from, scar: gnd });
    return;
  }
  // AC-130: очередь мелкого калибра и снаряд 105 мм
  if (k === "gunship") {
    guns(a, P(to), { hit: step.hit, n: 4, delay: 200 });
    shell(a, P(to), { hit: step.hit, delay: 520, size: 0.1, flash: false, scar: gnd });
    return;
  }
  if (k === "launch" && step.fx) {
    // снаряд в бою: вспышка у ствола, а сам он летит в залпе конца раунда; вне боя долетает сразу
    if (step.wait) { if (from && seen(from)) muzzle(a, toward(a, P(to)()), 250 + i * 120, step.fx === "arty" ? 0.09 : 0.06); return; }
    return shell(a, P(to), { hit: null, delay: 250 + i * 120, arc: step.fx === "arty" ? 0.18 : 0, size: 0.1, scar: gnd });
  }
  if (k === "launch") {
    const ally = ours(step.from);
    // пуск в бою: ракета уходит на 70 % пути и висит до залпа; вне боя долетает и рвётся
    const stop = step.wait ? AIR_AT : 1;
    missile(() => a, P(to), {
      delay: 250 + i * 120, stop, color: ally ? 0xbfefff : 0xffd8c8,
      done: p => { if (step.wait && message) { launched.set(message.id, a); syncAir(); } else { boom(p, 0.1); if (gnd) scar(p, 0.13); } }
    });
  }
}

/** Залп: ракеты каждой карточки по цели доходят от своей висящей метки или от стрелка. */
function impact(step) {
  const to = tokenFor(step.to);
  if (!to || !seen(to)) return;
  const tp = P(to), gnd = onGround(to);
  // снаряды и навес летят от стрелков целиком; ракеты — от своих меток в воздухе
  const fx = step.fx ?? {}, shooters = step.from.filter(u => fx[u]), rockets = step.from.filter(u => !fx[u]);
  shooters.forEach((u, j) => {
    const o = origin(tokenFor(u), to), arc = fx[u] === "arty" ? 0.18 : 0;
    if (tokenFor(u) && seen(tokenFor(u))) muzzle(o, toward(o, tp()), j * 160, arc ? 0.09 : 0.06);
    shell(o, tp, { hit: step.hit || step.ship ? true : false, delay: j * 160 + 60, arc, size: arc ? 0.12 : 0.09, flash: false, scar: gnd });
  });
  if (!rockets.length) return;
  const starts = takeLanding(step.to);
  while (starts.length < Math.max(1, Math.min(step.count - shooters.length, 6))) {
    const sh = tokenFor(rockets[starts.length % rockets.length]);
    const o = origin(sh, to), p = tp();
    starts.push(p ? lerp(o, p, AIR_AT) : o);
  }
  if (step.broke) later(200, () => { const p = tp(); if (p) flares(p, to.document.rotation); });
  starts.forEach((s, j) => {
    const opts = { delay: j * 160, color: 0xffe6c8 };
    if (step.bomb) return bomb(s, tp, { hit: step.hit || step.ship, delay: j * 160, scar: gnd });
    if (step.hit || step.ship) missile(() => s, tp, { ...opts, done: p => { boom(step.prox ? { x: p.x + gs() * 0.08, y: p.y - gs() * 0.06 } : p, j ? 0.09 : 0.13); if (gnd) scar(p, j ? 0.12 : 0.15); } });
    else missile(() => s, tp, { ...opts, miss: true });
  });
}

/* ---------- ракеты в воздухе ---------- */

const AIR_AT = 0.7;
const launched = new Map();   // id карточки → точка пуска (до перезагрузки)
const air = new Map();        // id карточки → { from: точка, to: токен, ally, msg }
const landing = [];           // сошли с неба: { to (uuid), at (точка), t } — залп заберёт их точки
let syncTimer = null;
function syncSoon() { clearTimeout(syncTimer); syncTimer = setTimeout(() => syncAir(), 60); }

/** Метки ракет в воздухе по карточкам текущего боя этой сцены. */
function syncAir() {
  if (!canvas?.ready) return;
  const want = new Map();
  // в воздухе только ракеты этого и следующего раунда: хватает хвоста чата
  if (on()) for (const m of (game.messages?.contents ?? []).slice(-300)) {
    const c = m.getFlag?.(SYSTEM_ID, "card");
    if (!marked(c) || !game.combat || !String(c.combatKey).startsWith(`${game.combat.id}:`)) continue;
    const to = tokenFor(c.targetUuid), sh = tokenFor(c.actorUuid);
    if (!to || !seen(to)) continue;
    // ракета ещё летит от стрелка (анимация пуска): метку ставит она сама
    if (!launched.has(m.id) && sh && Date.now() - (m.timestamp ?? 0) < 2500) continue;
    want.set(m.id, { from: launched.get(m.id) ?? (sh ? origin(sh, to) : origin(null, to)), to, uuid: c.targetUuid, ally: ours(c.actorUuid) });
  }
  for (const [id, e] of air) if (!want.has(id)) {
    air.delete(id);
    const p = e.to.destroyed ? null : lerp(e.from, P(e.to)(), AIR_AT);
    if (p) landing.push({ to: e.uuid, at: p, t: Date.now() });
  }
  for (const [id, e] of want) if (!air.has(id)) air.set(id, e);
  // сошедшие без залпа (захват сорван, карточка удалена): гаснут на месте
  later(900, () => {
    for (let i = landing.length - 1; i >= 0; i--) if (Date.now() - landing[i].t > 800) { puffs(landing[i].at, 4); landing.splice(i, 1); }
  });
  if (air.size) start();
}
function takeLanding(uuid) {
  const out = [];
  for (let i = landing.length - 1; i >= 0; i--) if (landing[i].to === uuid) { out.unshift(landing[i].at); landing.splice(i, 1); }
  return out;
}

function drawAir(g, now) {
  for (const [id, e] of air) {
    if (e.to.destroyed || e.to.document?.parent !== canvas.scene) { air.delete(id); continue; }
    const b = P(e.to)(), p = lerp(e.from, b, AIR_AT), col = e.ally ? 0x7fd8ff : 0xff7a5a;
    // пунктир от пуска до цели и мигающая метка ракеты
    const n = Math.max(2, Math.floor(dist(e.from, b) / (gs() * 0.06)));
    g.lineStyle(Math.max(1, gs() * 0.008), col, 0.35);
    for (let i = 0; i < n; i += 2) { const q1 = lerp(e.from, b, i / n), q2 = lerp(e.from, b, Math.min(1, (i + 1) / n)); g.moveTo(q1.x, q1.y); g.lineTo(q2.x, q2.y); }
    g.lineStyle(0);
    const pulse = 0.6 + 0.4 * Math.sin(now / 180);
    dart(g, p, Math.atan2(b.y - p.y, b.x - p.x), gs() * 0.07, col, pulse);
  }
}

/* ---------- дым и огонь повреждённых: клубы остаются на месте, поэтому за летящей машиной тянется след ---------- */

const BURN_MS = 140;
const burnOn = () => { try { return on() && game.settings.get(SYSTEM_ID, "fxBurn") !== false; } catch { return true; } };
function burnTick() {
  if (!canvas?.ready || !burnOn() || document.hidden) return;
  // частиц и так много (большой залп): дым подождёт
  if (items.length > MAX_ITEMS * 0.6) return;
  for (const t of canvas.tokens?.placeables ?? []) {
    const kind = burnOf(t.actor);
    if (!kind || t.document.hidden || !seen(t)) continue;
    const c = t.center, w = (t.w ?? gs()) * 0.18;
    const at = { x: c.x + rnd(-w, w), y: c.y + rnd(-w, w) };
    // дым тянет немного вверх, как ветром
    puff(at, { r: 0.02, life: 1900, color: kind === "fire" ? 0x3a3a3a : 0x8a8a8a, alpha: kind === "fire" ? 0.55 : 0.4, grow: 2.4, vx: rnd(-4, 4), vy: -rnd(6, 14) });
    if (kind === "fire") {
      puff({ x: c.x + rnd(-w, w), y: c.y + rnd(-w, w) }, { r: 0.016, life: 420, color: Math.random() < 0.5 ? 0xff7a1a : 0xffc23a, alpha: 0.85, grow: 0.8, vy: -rnd(8, 18) });
    }
  }
}

/* ---------- инверсионный след: белые нитки от двигателей машины (contrails.mjs) на Высокой, тают и расплываются ---------- */

const trailAt = new Map();   // id токена → где был центр в прошлый тик
const trailOn = () => { try { return on() && game.settings.get(SYSTEM_ID, "fxTrail") !== false; } catch { return true; } };
const burnerOn = () => { try { return on() && game.settings.get(SYSTEM_ID, "fxBurner") !== false; } catch { return true; } };
const wakeOn = () => { try { return on() && game.settings.get(SYSTEM_ID, "fxWake") !== false; } catch { return true; } };

function trailTick() {
  const trail = trailOn(), burner = burnerOn(), wake = wakeOn();
  if (!canvas?.ready || (!trail && !burner && !wake) || document.hidden) return;
  if (items.length > MAX_ITEMS * 0.6) return;
  const live = new Set(), cold = canvas.scene?.getFlag?.(SYSTEM_ID, "place") === "cold";
  for (const t of canvas.tokens?.placeables ?? []) {
    if (t.document.hidden || !seen(t)) continue;
    const surf = wake ? groundTrailOf(t.actor, terrainAt(t.center)) : null;
    if (surf) {
      live.add(t.id);
      const now = { x: t.center.x, y: t.center.y }, was = trailAt.get(t.id);
      trailAt.set(t.id, now);
      // колея — по узкой стороне корпуса (линкор длинный), остальное — по ширине токена
      const size = surf === "tracks" ? Math.min(t.w ?? gs(), t.h ?? gs()) : t.w ?? gs();
      if (was && Math.hypot(now.x - was.x, now.y - was.y) <= gs() * 2.5) surfTrail(surf, was, now, size, cold);
      continue;
    }
    if (!isFlying(t.actor)) continue;
    const high = trail && trailOf(t), fast = burner && burnerOf(t.actor);
    if (!high && !fast) continue;
    live.add(t.id);
    const now = { x: t.center.x, y: t.center.y }, was = trailAt.get(t.id);
    trailAt.set(t.id, now);
    // перенос токена ведущим (прыжок дальше пары клеток за тик) следа не оставляет
    if (!was || Math.hypot(now.x - was.x, now.y - was.y) > gs() * 2.5) continue;
    const size = t.w ?? gs();
    if (high) {
      const eng = enginesOf(t.document.texture?.src ?? t.actor?.img, t.actor);
      const lines = contrailLines(was, now, t.h ?? size, size, eng);
      if (lines.length) contrail(lines, eng, size);
    }
    if (fast) afterburner(was, now, size);
  }
  for (const id of trailAt.keys()) if (!live.has(id)) trailAt.delete(id);
}

/** Точка сопла: позади центра по направлению движения или null (стоит на месте). */
export function nozzleAt(a, b, size) {
  const d = Math.hypot(b.x - a.x, b.y - a.y);
  if (d < 2) return null;
  const ux = (b.x - a.x) / d, uy = (b.y - a.y) / d;
  return { x: b.x - ux * size * 0.4, y: b.y - uy * size * 0.4, ux, uy };
}

/** Пламя форсажа: яркое ядро у сопла и рыжие языки, которые тут же отстают и гаснут. */
function afterburner(a, b, size) {
  const n = nozzleAt(a, b, size);
  if (!n) return;
  const back = (k, sp) => ({ vx: -n.ux * sp * k, vy: -n.uy * sp * k });
  puff({ x: n.x, y: n.y }, { r: 0.022, life: 220, color: 0xfff2c0, alpha: 0.95, grow: 0.3, ...back(1, 60) });
  for (let i = 0; i < 2; i++) {
    puff({ x: n.x - n.ux * rnd(2, 8), y: n.y - n.uy * rnd(2, 8) }, { r: 0.02, life: 320, color: Math.random() < 0.5 ? 0xff8a1e : 0xffc23a, alpha: 0.8, grow: 0.6, delay: i * 50, ...back(1, rnd(90, 160)) });
  }
}

/** Точки следа по пройденному отрезку: шаг в долю клетки, у каждой — направление движения (для расхождения волн). */
export function surfPoints(a, b, size, step = 0.07) {
  const n = nozzleAt(a, b, size);
  if (!n) return [];
  const d = Math.hypot(b.x - a.x, b.y - a.y), k = Math.max(1, Math.round(d / (size * step)));
  return Array.from({ length: k }, (_, i) => ({ x: n.x - (b.x - a.x) * (1 - (i + 1) / k), y: n.y - (b.y - a.y) * (1 - (i + 1) / k), ux: n.ux, uy: n.uy, i, k }));
}

/** Местность под точкой из карты местности сцены (импорт миссии) или null. */
function terrainAt(p) {
  const cells = canvas.scene?.getFlag?.(SYSTEM_ID, "terrainCells"), g = gs();
  return cells && g ? cells[`${Math.floor(p.x / g)},${Math.floor(p.y / g)}`] ?? null : null;
}

/** Колея гусениц: TRACKS полос по ширине корпуса, на каждой — поперечные отпечатки траков с шагом step доли клетки.
    Возвращает отрезки отпечатков [{ x1, y1, x2, y2 }] по пройденному пути a → b. */
export const TRACKS = [-0.38, -0.2, 0.2, 0.38];
export function treadMarks(a, b, size, step = 0.055) {
  const d = Math.hypot(b.x - a.x, b.y - a.y);
  if (d < 2) return [];
  const ux = (b.x - a.x) / d, uy = (b.y - a.y) / d, nx = -uy, ny = ux, half = size * 0.065, k = Math.max(1, Math.floor(d / (size * step)));
  const out = [];
  for (let i = 0; i < k; i++) {
    const cx = a.x + ux * d * (i / k), cy = a.y + uy * d * (i / k);
    for (const o of TRACKS) {
      const x = cx + nx * size * o, y = cy + ny * size * o;
      out.push({ x1: x - nx * half, y1: y - ny * half, x2: x + nx * half, y2: y + ny * half });
    }
  }
  return out;
}
const TRACK_MS = 9000;
/** Колея линкора: тёмные отпечатки траков ложатся на землю (на снегу — серо-голубые) и долго тают; над ними немного пыли. */
function tracks(a, b, size, cold) {
  const marks = treadMarks(a, b, size);
  if (!marks.length) return;
  const color = cold ? 0x7d8a9c : 0x3a2f22, w = Math.max(1.5, size * 0.03);
  add((t, g) => {
    const k = t / TRACK_MS;
    if (k >= 1) return false;
    g.lineStyle(w, color, 0.5 * (k < 0.7 ? 1 : 1 - (k - 0.7) / 0.3));
    for (const m of marks) { g.moveTo(m.x1, m.y1); g.lineTo(m.x2, m.y2); }
    g.lineStyle(0);
  });
  // гусеницы взбивают пыль (снег) по краям корпуса
  const n = nozzleAt(a, b, size);
  if (n) for (const s of [-1, 1]) puff({ x: b.x - n.uy * size * 0.45 * s - n.ux * size * 0.3, y: b.y + n.ux * size * 0.45 * s - n.uy * size * 0.3 },
    { r: 0.03, life: 1900, color: cold ? 0xf2f6fb : 0xa89478, alpha: 0.28, grow: 2.4, vx: -n.ux * gs() * 0.05 + rnd(-4, 4), vy: -n.uy * gs() * 0.05 + rnd(-4, 4) });
}

/** Кильватер: белая пена за кормой расходится в обе стороны клином; пыль: бурые клубы оседают за техникой. */
function surfTrail(kind, a, b, size, cold) {
  if (kind === "tracks") return tracks(a, b, size, cold);
  const pts = surfPoints(a, b, size);
  for (const p of pts) {
    const delay = (p.i / p.k) * 120;
    if (kind === "wake") {
      const side = gs() * 0.05;
      for (const s of [-1, 1]) puff({ x: p.x, y: p.y }, { r: 0.008, life: 4200, color: 0xf4fbff, alpha: 0.5, grow: 1.2, delay, vx: -p.uy * side * s - p.ux * side * 0.25, vy: p.ux * side * s - p.uy * side * 0.25 });
      if (p.i % 2 === 0) puff({ x: p.x + rnd(-2, 2), y: p.y + rnd(-2, 2) }, { r: 0.016, life: 2600, color: 0xe6f2f8, alpha: 0.35, grow: 1.4, delay });
    } else if (p.i % 2 === 0) {
      const color = cold ? 0xf2f6fb : Math.random() < 0.5 ? 0xb8a07a : 0xa89478;
      puff({ x: p.x + rnd(-3, 3), y: p.y + rnd(-3, 3) }, { r: 0.022, life: 1700, color, alpha: 0.32, grow: 2.2, delay, vx: -p.ux * gs() * 0.06 + rnd(-4, 4), vy: -p.uy * gs() * 0.06 + rnd(-4, 4) });
    }
  }
}

/** Нитки следа: со временем толще и бледнее; близкие нитки (спарка истребителя) сходятся в одну, у тяжёлых держатся порознь. */
function contrail(lines, eng, size) {
  const st = CONTRAIL[eng.cls] ?? CONTRAIL.jet, base = Math.max(1, size * st.width * (eng.w ?? 1));
  add((t, g) => {
    const k = t / st.life;
    if (k >= 1) return false;
    g.lineStyle(base * (1 + st.spread * k), 0xf4f8ff, st.alpha * (1 - k) ** 1.5);
    const m = 1 - st.merge * Math.min(1, k * 1.2);
    for (const l of lines) {
      const ox = l.nx * l.off * m, oy = l.ny * l.off * m;
      g.moveTo(l.from.x + ox, l.from.y + oy); g.lineTo(l.to.x + ox, l.to.y + oy);
    }
    g.lineStyle(0);
  });
}

/* ---------- пар и вихри: конус пара с хлопком на разгоне до максимальной Speed, нити вихрей с крыльев на Break! ---------- */

const vaporOn = () => { try { return on() && game.settings.get(SYSTEM_ID, "fxVapor") !== false; } catch { return true; } };
const atMax = new Set();   // uuid машин, которые уже идут на максимальной Speed: конус только на переходе
/** Перешла ли машина на максимальную Speed этим изменением: speed в изменении, теперь на максимуме, раньше не была. */
export function vaporEdge(actor, change, seenMax = atMax) {
  const sys = change?.system ?? {};
  if (!actor?.uuid || !("speed" in sys || "maxSpeed" in sys)) return false;
  if (!burnerOf(actor)) { seenMax.delete(actor.uuid); return false; }
  if (seenMax.has(actor.uuid)) return false;
  seenMax.add(actor.uuid);
  return true;
}
function onSpeed(actor, change) {
  // расстановка и импорт миссии меняют Speed пачкой: пар только в бою
  if (!vaporEdge(actor, change) || !game.combat?.started || !vaporOn() || !canvas?.ready) return;
  const toks = actor.isToken ? [actor.token?.object] : actor.getActiveTokens?.() ?? [];
  let shown = false;
  for (const t of toks) if (t && !t.document.hidden && seen(t)) { vaporCone(t); shown = true; }
  if (shown) import("./sounds.mjs").then(m => m.cueAll("sonic")).catch(() => null);
}

/** Нос токена: курс 0 — нос вверх, по часовой; угол в радианах экрана. */
const noseOf = rot => ((Number(rot) || 0) - 90) * Math.PI / 180;
/** Конус пара сверху: вершина впереди центра, бока колоколом расходятся назад, кромка раструба выгнута за хвостом.
    scale — доля размера (слои плотности). Точки многоугольника и отдельно кромка. */
export function coneShape(c, rot, size, scale = 1) {
  const a = noseOf(rot), ux = Math.cos(a), uy = Math.sin(a), nx = -uy, ny = ux;
  const ahead = size * 0.3 * scale, behind = size * 0.34 * scale, R = size * 0.56 * scale;
  const at = (s, w) => ({ x: c.x + ux * (ahead - (ahead + behind) * s) + nx * w, y: c.y + uy * (ahead - (ahead + behind) * s) + ny * w });
  const side = sgn => Array.from({ length: 7 }, (_, i) => { const s = i / 6; return at(s, sgn * R * Math.sqrt(s)); });
  // кромка: дуга от левого края раструба к правому через точку за хвостом
  const rim = Array.from({ length: 11 }, (_, i) => { const t = Math.PI * (i / 10 - 0.5); return at(1 + 0.32 * Math.cos(t) * R / (ahead + behind), -R * Math.sin(t)); });
  return { pts: [...side(-1), ...rim, ...side(1).reverse()], rim, ux, uy };
}
function vaporCone(t) {
  const size = Math.min(t.w ?? gs(), t.h ?? gs()), LIFE = 1000;
  add((ms, g) => {
    if (!t || t.destroyed) return false;
    const k = ms / LIFE;
    if (k >= 1) return false;
    const fade = k < 0.1 ? k / 0.1 : (1 - (k - 0.1) / 0.9) ** 1.3;
    // пар срывается за машиной: конус раздувается и отстаёт
    const c = { x: t.center.x, y: t.center.y }, rot = t.document.rotation, grow = 1 + 0.3 * k, drift = size * 0.15 * k;
    const shift = (q, sh) => [q.x - sh.ux * drift, q.y - sh.uy * drift];
    // плотнее у оси: три слоя, внутренние уже
    for (const [sc, al] of [[1, 0.13], [0.78, 0.13], [0.55, 0.14]]) {
      const sh = coneShape(c, rot, size * grow, sc);
      g.beginFill(0xf4f8ff, al * fade); g.drawPolygon(sh.pts.flatMap(q => shift(q, sh))); g.endFill();
    }
    // кромка раструба: широкое свечение и яркая линия
    const sh = coneShape(c, rot, size * grow);
    for (const [w, al] of [[0.09, 0.22], [0.035, 0.8]]) {
      g.lineStyle(Math.max(1.5, size * w), 0xffffff, al * fade);
      sh.rim.forEach((q, i) => { const [x, y] = shift(q, sh); if (i) g.lineTo(x, y); else g.moveTo(x, y); });
    }
    g.lineStyle(0);
  });
  // хлопок: тонкое кольцо ударной волны расходится от машины
  const c0 = { x: t.center.x, y: t.center.y };
  add((ms, g) => {
    const k = ms / 750;
    if (k >= 1) return false;
    g.lineStyle(Math.max(1, size * 0.025 * (1 - k)), 0xffffff, 0.55 * (1 - k)); g.drawCircle(c0.x, c0.y, size * (0.35 + 2.1 * k)); g.lineStyle(0);
  }, 70);
}

/** Нить вихря с законцовки крыла side (−1 левое, 1 правое): назад от крыла, загибаясь в сторону виража turn. */
export function vortexPath(c, rot, size, side, turn, n = 14) {
  const a = noseOf(rot), ux = Math.cos(a), uy = Math.sin(a), nx = -uy, ny = ux;
  const tip = { x: c.x + nx * size * 0.42 * side - ux * size * 0.05, y: c.y + ny * size * 0.42 * side - uy * size * 0.05 };
  return Array.from({ length: n }, (_, i) => {
    const u = i / (n - 1), back = size * 0.95 * u, curl = size * 0.45 * u * u * turn;
    return { x: tip.x - ux * back + nx * curl, y: tip.y - uy * back + ny * curl };
  });
}
function vortices(t) {
  const size = Math.min(t.w ?? gs(), t.h ?? gs()), c = { x: t.center.x, y: t.center.y }, rot = t.document.rotation;
  const turn = Math.random() < 0.5 ? -1 : 1, LIFE = 1500, DRAW = 320;
  const paths = [-1, 1].map(side => vortexPath(c, rot, size, side, turn));
  add((ms, g) => {
    const k = ms / LIFE;
    if (k >= 1) return false;
    // нить тянется от крыла за DRAW мс, потом бледнеет и расплывается
    const upto = Math.max(2, Math.ceil(Math.min(1, ms / DRAW) * paths[0].length));
    g.lineStyle(Math.max(1, size * 0.014 * (1 + 1.5 * k)), 0xf4f8ff, 0.7 * (1 - k) ** 1.4);
    for (const p of paths) { g.moveTo(p[0].x, p[0].y); for (let i = 1; i < upto; i++) g.lineTo(p[i].x, p[i].y); }
    g.lineStyle(0);
  });
}

/* ---------- воронки и подпалины: под токенами, тают за три раунда (вне боя за пару минут) ---------- */

const scars = [];
let scarGfx = null, scarTimer = null;
const SCAR_ROUNDS = 3, SCAR_MS = 150000, MAX_SCARS = 120;
const cratersOn = () => { try { return on() && game.settings.get(SYSTEM_ID, "fxCraters") !== false; } catch { return true; } };
/** Стоит ли цель на земле: наземная техника, здания и сухопутный линкор на суше; не самолёт, не корабль, не вода. */
function onGround(t) {
  const a = t?.actor;
  if (!a || isFlying(a)) return false;
  if (a.type !== "npc") return false;
  const s = a.system ?? {};
  if (s.kind === "ship" && !hasRule(a, "landship")) return false;
  return !WATER.includes(terrainAt(t.center));
}
/** Насколько видна воронка (0..1): в бою по раундам с её раунда, вне боя по времени. */
export function scarAlpha(sc, round, now) {
  if (sc.round != null && round != null) { const age = round - sc.round; return age >= SCAR_ROUNDS || age < 0 ? 0 : [1, 0.65, 0.35][age]; }
  const k = (now - sc.at) / SCAR_MS;
  return k >= 1 ? 0 : 1 - k * k;
}
/** Неровный край пятна: n точек на радиусе r с разбросом по seed (одинаково при каждой перерисовке). */
export function blotPoints(x, y, r, seed, n = 14) {
  let z = seed >>> 0 || 1;
  const rand = () => { z = (z * 1664525 + 1013904223) >>> 0; return z / 4294967296; };
  return Array.from({ length: n }, (_, i) => { const a = (i / n) * Math.PI * 2, k = 0.72 + rand() * 0.45; return { x: x + Math.cos(a) * r * k, y: y + Math.sin(a) * r * k }; });
}
function scar(p, size = 0.14, kind = "crater") {
  if (!p || !cratersOn() || !canvas?.ready) return;
  if (WATER.includes(terrainAt(p))) return;
  const round = game.combat?.started ? game.combat.round : null;
  scars.push({ x: p.x, y: p.y, r: gs() * size, kind, seed: Math.floor(Math.random() * 2 ** 31), round, at: Date.now() });
  if (scars.length > MAX_SCARS) scars.splice(0, scars.length - MAX_SCARS);
  drawScars();
}
// PrimaryGraphics в v12 объявлен в общем скрипте через class: виден по имени, но не как globalThis.PrimaryGraphics
const PGClass = () => foundry.canvas?.primary?.PrimaryGraphics ?? (typeof PrimaryGraphics === "function" ? PrimaryGraphics : null);
function scarLayer() {
  if (!canvas?.ready) return null;
  if (scarGfx && !scarGfx.destroyed) return scarGfx;
  const PG = PGClass();
  // под токенами, над картой и плитками местности; без PrimaryGraphics — в слое схемы
  if (PG && canvas.primary) {
    scarGfx = canvas.primary.addChild(new PG({ name: "tbScars" }));
    scarGfx.elevation = 0;
    const L = foundry.canvas?.groups?.PrimaryCanvasGroup?.SORT_LAYERS ?? (typeof PrimaryCanvasGroup === "function" ? PrimaryCanvasGroup.SORT_LAYERS : null);
    scarGfx.sortLayer = L?.TILES ?? 500;
    scarGfx.sort = 1e6;
  } else {
    if (!canvas.interface) return null;
    scarGfx = canvas.interface.addChildAt(new PIXI.Graphics(), 0);
  }
  scarGfx.eventMode = "none";
  return scarGfx;
}
function drawScars() {
  clearTimeout(scarTimer);
  const round = game.combat?.started ? game.combat.round : null, now = Date.now();
  for (let i = scars.length - 1; i >= 0; i--) if (scarAlpha(scars[i], round, now) <= 0) scars.splice(i, 1);
  if (!canvas?.ready) return;
  if (!scars.length && !scarGfx) return;
  const g = scarLayer();
  if (!g) return;
  g.clear();
  if (!cratersOn()) return;
  for (const sc of scars) {
    const k = scarAlpha(sc, round, now), r = sc.r;
    // подпалина: неровное тёмное пятно и копоть лучами
    g.beginFill(0x1c150f, 0.42 * k); g.drawPolygon(blotPoints(sc.x, sc.y, r, sc.seed).flatMap(q => [q.x, q.y])); g.endFill();
    g.lineStyle(Math.max(1, r * 0.07), 0x241a12, 0.28 * k);
    blotPoints(sc.x, sc.y, r * 1.55, sc.seed + 7, 9).forEach(q => { g.moveTo(sc.x, sc.y); g.lineTo(q.x, q.y); });
    g.lineStyle(0);
    if (sc.kind === "scorch") {
      g.beginFill(0x0b0907, 0.35 * k); g.drawPolygon(blotPoints(sc.x, sc.y, r * 0.6, sc.seed + 3, 10).flatMap(q => [q.x, q.y])); g.endFill();
      continue;
    }
    // воронка: неровный вал выброшенной земли и тёмная яма
    g.beginFill(0x6e5c46, 0.3 * k); g.drawPolygon(blotPoints(sc.x, sc.y, r * 0.55, sc.seed + 11, 11).flatMap(q => [q.x, q.y])); g.endFill();
    g.beginFill(0x0d0a07, 0.55 * k); g.drawPolygon(blotPoints(sc.x, sc.y, r * 0.38, sc.seed + 5, 10).flatMap(q => [q.x, q.y])); g.endFill();
  }
  // вне боя воронки тают по времени: перерисовать, пока есть что гасить
  if (scars.some(sc => sc.round == null || round == null)) scarTimer = setTimeout(drawScars, 5000);
}

/* ---------- движок: один слой, всё перерисовывается каждый кадр ---------- */

const items = [];
let gfx = null, ticking = false, clock = 0;
function layer() {
  if (!canvas?.ready || !canvas.interface) return null;
  if (!gfx || gfx.destroyed) { gfx = canvas.interface.addChild(new PIXI.Graphics()); gfx.eventMode = "none"; }
  return gfx;
}
// предел одновременных частиц: большой залп не должен тормозить карту
const MAX_ITEMS = 1500;
function add(draw, delay = 0) { if (items.length >= MAX_ITEMS) return; items.push({ at: clock + delay, draw }); start(); }
function later(ms, f) { add(t => { if (t < ms) return true; f(); return false; }); }
function start() {
  const tk = canvas?.app?.ticker;
  if (ticking || !tk) return;
  tk.add(tick);
  ticking = true;
}
function stop() { canvas?.app?.ticker?.remove(tick); ticking = false; }
function clearAll() {
  items.length = 0; air.clear(); landing.length = 0;
  try { if (gfx && !gfx.destroyed) gfx.destroy(); } catch { /* слой уже снят вместе со сценой */ }
  gfx = null;
  stop();
}
/* Ошибка в обработчике тикера PIXI обрывает весь цикл отрисовки Foundry: карта перестаёт обновляться.
   Поэтому кадр схемы целиком под try: при сбое схема гаснет, а карта живёт дальше. */
function tick() {
  try { frame(); }
  catch (err) { console.warn(`${SYSTEM_ID} | анимация остановлена`, err); report(`анимация остановлена: ${err?.message ?? err}`); clearAll(); }
}
function frame() {
  clock += canvas.app.ticker.deltaMS;
  const g = layer();
  if (!g) return stop();
  g.clear();
  const keep = [];
  for (const it of items.splice(0)) {
    const t = clock - it.at;
    if (t < 0) { keep.push(it); continue; }
    let alive = false;
    try { alive = it.draw(t, g) !== false; } catch (err) { console.warn(`${SYSTEM_ID} | анимация`, err); }
    if (alive) keep.push(it);
  }
  items.unshift(...keep);
  drawAir(g, clock);
  if (!items.length && !air.size) { g.clear(); stop(); }
}

/* ---------- примитивы ---------- */

/** Треугольник-ракета носом по углу ang. */
function dart(g, p, ang, len, color, alpha = 1) {
  const c = Math.cos(ang), s = Math.sin(ang), w = len * 0.35;
  g.beginFill(color, alpha);
  g.drawPolygon([p.x + c * len * 0.6, p.y + s * len * 0.6, p.x - c * len * 0.4 - s * w, p.y - s * len * 0.4 + c * w, p.x - c * len * 0.4 + s * w, p.y - s * len * 0.4 - c * w]);
  g.endFill();
}
function puff(p, { r = 0.025, life = 700, color = 0xd8d8d8, alpha = 0.5, grow = 1.6, vx = 0, vy = 0, delay = 0 } = {}) {
  const R = gs() * r;
  add((t, g) => {
    const k = t / life;
    if (k >= 1) return false;
    g.beginFill(color, alpha * (1 - k));
    g.drawCircle(p.x + vx * t / 1000, p.y + vy * t / 1000, R * (1 + grow * k));
    g.endFill();
  }, delay);
}
function puffs(p, n) { for (let i = 0; i < n; i++) puff({ x: p.x + rnd(-6, 6), y: p.y + rnd(-6, 6) }, { r: 0.02, life: 900, color: 0x9a9a9a, delay: i * 60 }); }

/**
 * Ракета от a к b (функции точек: цель может уходить Break!). stop — доля пути (0.7 — повиснуть до залпа),
 * miss — пролетает мимо и гаснет, done(p) — по прибытии.
 */
function missile(a, b, { delay = 0, stop = 1, miss = false, color = 0xffffff, done = null, curve = 0.2 } = {}) {
  const A0 = a(), B0 = b();
  if (!A0 || !B0) return;
  const len = dist(A0, B0), dur = Math.min(1500, 380 + (len / gs()) * 260) * stop;
  const side = Math.random() < 0.5 ? -1 : 1, bend = rnd(0.6, 1.25) * curve * side;
  const off = miss ? { x: rnd(-1, 1) * gs() * 0.12, y: rnd(-1, 1) * gs() * 0.12 } : { x: 0, y: 0 };
  let last = null, ang = 0, fin = null;
  add((t, g) => {
    const A = a() ?? A0, B0b = b() ?? B0, B = { x: B0b.x + off.x, y: B0b.y + off.y };
    if (fin === null) {
      const u = Math.min(1, t / dur) * stop;
      // кривая Безье: стартует вбок, к концу ложится на цель
      const m = lerp(A, B, 0.5), nx = -(B.y - A.y), ny = B.x - A.x, ctl = { x: m.x + nx * bend, y: m.y + ny * bend };
      const e = u * u * (3 - 2 * u) * 0.35 + u * 0.65;
      const p = { x: (1 - e) ** 2 * A.x + 2 * (1 - e) * e * ctl.x + e * e * B.x, y: (1 - e) ** 2 * A.y + 2 * (1 - e) * e * ctl.y + e * e * B.y };
      if (last) ang = Math.atan2(p.y - last.y, p.x - last.x);
      if (!last || dist(last, p) > gs() * 0.012) { puff(p, { r: 0.012, life: 650 }); last = p; }
      dart(g, p, ang, gs() * 0.07, color);
      if (t < dur) return true;
      if (!miss) { done?.(p); return false; }
      fin = { p, t };
    }
    // промах: дальше по прямой и гаснет
    const k = (t - fin.t) / 450;
    if (k >= 1) return false;
    const q = { x: fin.p.x + Math.cos(ang) * gs() * 0.45 * k, y: fin.p.y + Math.sin(ang) * gs() * 0.45 * k };
    if (dist(last, q) > gs() * 0.015) { puff(q, { r: 0.01, life: 500 }); last = q; }
    dart(g, q, ang, gs() * 0.07, color, 1 - k);
    return true;
  }, delay);
}

function boom(p, size = 0.12) {
  if (!p) return;
  const R = gs() * size;
  add((t, g) => {
    if (t > 520) return false;
    const k = t / 520;
    if (t < 140) { g.beginFill(0xffffff, 0.9 * (1 - t / 140)); g.drawCircle(p.x, p.y, R * (0.4 + t / 140 * 0.5)); g.endFill(); }
    g.beginFill(0xff8a2a, 0.75 * (1 - k)); g.drawCircle(p.x, p.y, R * (0.45 + 0.6 * k)); g.endFill();
    g.beginFill(0xffd27a, 0.8 * (1 - k)); g.drawCircle(p.x, p.y, R * (0.25 + 0.3 * k)); g.endFill();
    g.lineStyle(Math.max(1, R * 0.08), 0xffe0a0, 0.7 * (1 - k)); g.drawCircle(p.x, p.y, R * (0.6 + 1.1 * k)); g.lineStyle(0);
  });
  sparks(p, 9, size);
  for (let i = 0; i < 5; i++) puff({ x: p.x + rnd(-R, R) * 0.4, y: p.y + rnd(-R, R) * 0.4 }, { r: size * 0.35, life: 1500, color: 0x555555, alpha: 0.45, grow: 1.8, vy: -gs() * 0.05, delay: 140 + i * 50 });
}
function sparks(p, n = 6, size = 0.06) {
  const R = gs() * size;
  for (let i = 0; i < n; i++) {
    const a = rnd(0, Math.PI * 2), v = R * rnd(1.4, 2.6), life = rnd(260, 420);
    add((t, g) => {
      const k = t / life;
      if (k >= 1) return false;
      const r1 = v * k, r2 = v * Math.max(0, k - 0.18);
      g.lineStyle(Math.max(1, R * 0.07), 0xffe7a0, 1 - k);
      g.moveTo(p.x + Math.cos(a) * r2, p.y + Math.sin(a) * r2); g.lineTo(p.x + Math.cos(a) * r1, p.y + Math.sin(a) * r1);
      g.lineStyle(0);
    });
  }
}

/** Ловушки Break!: горящие точки веером назад от носа. */
function flares(p, rot = 0) {
  const back = (rot + 90) * Math.PI / 180;   // нос вверх: хвост — по направлению +90° от «вправо»
  for (let i = 0; i < 8; i++) {
    const a = back + rnd(-0.9, 0.9), v = gs() * rnd(0.25, 0.45), life = rnd(700, 1000);
    let last = null;
    add((t, g) => {
      const k = t / life;
      if (k >= 1) return false;
      const q = { x: p.x + Math.cos(a) * v * k, y: p.y + Math.sin(a) * v * k + gs() * 0.12 * k * k };
      if (!last || dist(last, q) > gs() * 0.02) { puff(q, { r: 0.008, life: 500, color: 0xeeeeee, alpha: 0.35 }); last = q; }
      g.beginFill(0xfff2c0, 1 - k * 0.7); g.drawCircle(q.x, q.y, gs() * 0.012); g.endFill();
    }, i * 50);
  }
}

/** Очереди: короткие трассеры; промах уходит мимо, попадание — искры. */
function guns(a, b, { hit = null, n = 6, rockets = false, delay = 0, scar: mark = false } = {}) {
  for (let i = 0; i < n; i++) {
    const off = hit === false ? { x: rnd(-1, 1) * gs() * 0.14, y: rnd(-1, 1) * gs() * 0.14 } : { x: rnd(-1, 1) * gs() * 0.02, y: rnd(-1, 1) * gs() * 0.02 };
    if (rockets) {
      missile(() => a, () => { const p = b(); return p && { x: p.x + off.x, y: p.y + off.y }; }, { delay: delay + i * 110, miss: hit === false, color: 0xffffff, curve: 0.04, done: p => { boom(p, 0.06); if (mark && i % 2 === 0) scar(p, 0.07); } });
      continue;
    }
    const life = Math.max(140, Math.min(320, dist(a, b() ?? a) / gs() * 160));
    add((t, g) => {
      const B0 = b();
      if (!B0) return false;
      const B = { x: B0.x + off.x, y: B0.y + off.y }, k = t / life, L = 0.12;
      if (k >= 1 + (hit === false ? 0.35 : 0)) { if (hit !== false && i % 2 === 0) sparks(B, 4, 0.04); return false; }
      const p1 = lerp(a, B, k), p2 = lerp(a, B, Math.max(0, k - L));
      g.lineStyle(Math.max(1, gs() * 0.01), 0xffe36a, 0.95); g.moveTo(p2.x, p2.y); g.lineTo(p1.x, p1.y); g.lineStyle(0);
    }, delay + i * 55);
  }
  if (hit) later(delay + n * 55 + 260, () => { const p = b(); if (p) boom(p, 0.07); });
}

/** Вспышка у ствола и клуб дыма: выстрел пушки или орудия. */
function muzzle(p, ang, delay = 0, size = 0.06) {
  if (!p) return;
  const R = gs() * size, f = { x: p.x + Math.cos(ang) * R * 0.8, y: p.y + Math.sin(ang) * R * 0.8 };
  add((t, g) => {
    if (t > 160) return false;
    const k = t / 160;
    g.beginFill(0xfff4c8, 0.95 * (1 - k)); g.drawCircle(f.x, f.y, R * (0.5 + 0.5 * k)); g.endFill();
    g.beginFill(0xffa040, 0.7 * (1 - k)); g.drawCircle(f.x + Math.cos(ang) * R * 0.5, f.y + Math.sin(ang) * R * 0.5, R * 0.35); g.endFill();
  }, delay);
  for (let i = 0; i < 3; i++) puff(f, { r: size * 0.35, life: 900, color: 0x8a8a8a, alpha: 0.4, grow: 1.8, vx: Math.cos(ang) * gs() * 0.06, vy: Math.sin(ang) * gs() * 0.06 - gs() * 0.02, delay: delay + 60 + i * 40 });
}

/** Пыль от промаха снаряда: земля, без огня. */
function dust(p) {
  for (let i = 0; i < 5; i++) puff({ x: p.x + rnd(-4, 4), y: p.y + rnd(-4, 4) }, { r: 0.025, life: 1100, color: 0x8a7a60, alpha: 0.5, grow: 1.6, vy: -gs() * 0.03, delay: i * 40 });
}

/**
 * Снаряд от a к b (b — функция точки): яркая точка с коротким хвостом, быстро и по прямой; arc — навес (артиллерия).
 * hit: true — разрыв, false — пыль рядом, null — исход неизвестен (разрыв поменьше).
 */
function shell(a, b, { hit = true, delay = 0, arc = 0, size = 0.09, flash = true, scar: mark = false } = {}) {
  const B0 = b();
  if (!a || !B0) return;
  const len = dist(a, B0), dur = arc ? Math.min(1700, 650 + (len / gs()) * 240) : Math.min(420, 120 + (len / gs()) * 70);
  const off = hit === false ? { x: rnd(-1, 1) * gs() * 0.16, y: rnd(-1, 1) * gs() * 0.16 } : { x: 0, y: 0 };
  if (flash) muzzle(a, Math.atan2(B0.y - a.y, B0.x - a.x), delay, arc ? 0.09 : 0.06);
  const at = (B, k) => { const p = lerp(a, B, k); if (arc) p.y -= arc * len * 4 * k * (1 - k); return p; };
  let last = null;
  add((t, g) => {
    const Bb = b() ?? B0, B = { x: Bb.x + off.x, y: Bb.y + off.y }, k = Math.min(1, t / dur);
    const p = at(B, k), q = at(B, Math.max(0, k - (arc ? 0.04 : 0.1)));
    g.lineStyle(Math.max(1.5, gs() * 0.016), 0xffb850, 0.9); g.moveTo(q.x, q.y); g.lineTo(p.x, p.y); g.lineStyle(0);
    g.beginFill(0xfff0c0, 1); g.drawCircle(p.x, p.y, gs() * (arc ? 0.016 + 0.012 * Math.sin(Math.PI * k) : 0.014)); g.endFill();
    if (arc && (!last || dist(last, p) > gs() * 0.04)) { puff(p, { r: 0.006, life: 450, alpha: 0.3 }); last = p; }
    if (k < 1) return true;
    if (hit === false) dust(B);
    else boom(B, hit === null ? size * 0.7 : size);
    // мимо тоже взрывает землю: воронка рядом с целью
    if (mark) scar(B, size * (hit === false ? 0.9 : 1.2));
    return false;
  }, delay);
}

function beam(a, b, { color = 0x9fe8ff, delay = 0, width = 0.05, life = 480 } = {}) {
  if (!a || !b) return;
  add((t, g) => {
    const k = t / life;
    if (k >= 1) return false;
    g.lineStyle(gs() * width * (1 - k), color, 0.25 * (1 - k)); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y);
    g.lineStyle(Math.max(1, gs() * 0.015 * (1 - k)), 0xffffff, 0.9 * (1 - k)); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y);
    g.lineStyle(0);
  }, delay);
}

/** Бомба: тёмная точка уменьшается к земле, внизу взрыв (промах — рядом). */
function bomb(a, b, { hit = true, delay = 0, scar: mark = false } = {}) {
  const off = hit ? { x: 0, y: 0 } : { x: rnd(-1, 1) * gs() * 0.15, y: rnd(-1, 1) * gs() * 0.15 };
  add((t, g) => {
    const B0 = b();
    if (!B0) return false;
    const B = { x: B0.x + off.x, y: B0.y + off.y }, k = t / 650;
    // бомба мимо цели тоже оставляет воронку
    if (k >= 1) { boom(B, hit ? 0.12 : 0.08); if (mark) scar(B, hit ? 0.17 : 0.13); return false; }
    const p = lerp(a, B, k);
    g.beginFill(0x202020, 0.9); g.drawCircle(p.x, p.y, gs() * (0.025 - 0.012 * k)); g.endFill();
  }, delay);
}

/** Удар по площади: несколько взрывов в каждой отмеченной зоне. */
function blastZones(zones) {
  const size = gs(), cells = [...new Set(zones.map(z => String(z).split("|")[0]))];
  cells.forEach((z, i) => {
    const [j, r] = z.split(",").map(Number);
    if (!Number.isFinite(j) || !Number.isFinite(r)) return;
    const tl = canvas.grid.getTopLeftPoint?.({ i: r, j }) ?? { x: j * size, y: r * size };
    for (let n = 0; n < 4; n++) later(i * 120 + n * 140, () => { const p = { x: tl.x + size * rnd(0.2, 0.8), y: tl.y + size * rnd(0.2, 0.8) }, r = rnd(0.12, 0.2); boom(p, r); scar(p, r * 1.1); });
  });
}

/** Сбитая машина: большой взрыв, потом дым. */
function downed(t) {
  const p = P(t)();
  if (!p) return;
  callout(t, "DESTROYED", 250);
  boom(p, 0.2);
  // сгоревшая наземная техника и здания: большая подпалина
  if (onGround(t)) later(300, () => scar(p, 0.24, "scorch"));
  later(180, () => boom({ x: p.x + rnd(-1, 1) * gs() * 0.06, y: p.y + rnd(-1, 1) * gs() * 0.06 }, 0.12));
  for (let i = 0; i < 10; i++) puff({ x: p.x + rnd(-4, 4), y: p.y }, { r: 0.04, life: 2200, color: 0x333333, alpha: 0.5, grow: 2.2, vx: rnd(-6, 6), vy: -gs() * 0.08, delay: 300 + i * 120 });
}
