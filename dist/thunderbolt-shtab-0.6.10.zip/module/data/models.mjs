/* Модели данных (TypeDataModel) для пилота, NPC, самолёта, спецоружия и триггера. */
import { SYSTEM_ID, TB, DT } from "../config.mjs";
import { squadLayout, squadPoints } from "../squadrons.mjs";
import { acePlaneStrain, ACE_STRAIN_EXTRA } from "../ace-kit.mjs";

const f = foundry.data.fields;
const int = (initial = 0, opts = {}) => new f.NumberField({ required: true, nullable: false, integer: true, initial, ...opts });
const nint = (initial = null) => new f.NumberField({ required: true, nullable: true, integer: true, initial });
const str = (initial = "") => new f.StringField({ required: true, blank: true, initial });
const bool = (initial = false) => new f.BooleanField({ required: true, initial });
const named = () => new f.ArrayField(new f.SchemaField({ key: str(), name: str(), text: str() }));
const SKILL_KEYS = Object.keys(TB.skills);
const skillSchema = () => new f.SchemaField(Object.fromEntries(SKILL_KEYS.map(k => [k, int(0, { min: 0, max: 10 })])));

/* Общее для всего, что летает или стоит на карте во время вылета. */
function sortieFields() {
  return {
    hp: new f.SchemaField({ value: int(3), max: int(3) }),
    strain: new f.SchemaField({ value: int(0), max: int(0) }),
    speed: int(1),
    alt: str("med"),
    breakEv: nint(),
    lock: str(), lockUuid: str(),
    markers: new f.SchemaField({
      grit: bool(), gritSkill: str(), structure: bool(), sys: str(), doom: bool(), lastRound: str()
    })
  };
}

/* Даунтайм: Нервы, «На пределе», Решимость, Заделы на следующий вылет, Связи, личные цели, долги. */
function downtimeFields() {
  return {
    nerves: int(0, { min: 0, max: DT.maxNerves }),
    onEdge: str(),                 // на Нервах 5 перед вылетом: "fly" — летит на пределе
    breakdown: str(),              // срыв в этом вылете: stupor, rage, panic ("" — ещё не было)
    resolve: int(0, { min: 0, max: DT.maxResolve }),
    fee: int(0, { min: 0, max: 5 }),   // Гонорар Наёмника (лимит 3, «Счёт к оплате» даёт сверх лимита)
    downtime: new f.SchemaField({
      actions: int(2, { min: 0, max: 2 }),   // сколько действий осталось в этом даунтайме
      resolveGot: bool(),                     // Решимость за этот даунтайм уже получена
      nervesDown: bool()                      // −1 Нервы в общей сцене уже было
    }),
    edges: new f.ArrayField(new f.SchemaField({
      id: str(), kind: str("custom"), stat: str(), minus: str(), minus2: str(), weapon: str(), skill: str(), mode: str(), text: str(),
      value: int(0), comp: bool(), used: bool(),
      carry: bool()                           // Память о погибшем в этом вылете: дожить до следующего
    })),
    bonds: new f.ArrayField(new f.SchemaField({
      name: str(), uuid: str(), npc: bool(), value: int(0, { min: 0, max: DT.maxBond }),
      was: new f.ArrayField(new f.NumberField({ integer: true })),   // прежние значения, зачёркнутые
      dead: bool(), used: bool(), usedGround: bool(), grown: bool()
    })),
    ...tieFields()
  };
}

/* Личные цели и долги (у пилота — часть даунтайма, у асов и дуэлянтов противника — личное дело). */
function tieFields() {
  return {
    goals: new f.ArrayField(new f.SchemaField({ name: str(), size: int(4), value: int(0, { min: 0 }) })),
    debts: new f.ArrayField(new f.SchemaField({ text: str(), struck: bool() }))
  };
}

/* Личное дело NPC (асы и дуэлянты противника, персонал): ФИО, звено, база, вопросы, Связи, цели, долги. */
function personFields() {
  return {
    lastName: str(), firstName: str(), patronymic: str(), rank: str(), flight: str(), squadron: str(), base: str(), birth: str(),
    status: str("active"),
    questions: new f.SchemaField({ callsign: str(), ground: str(), fear: str(), defy: str() }),
    bonds: new f.ArrayField(new f.SchemaField({
      name: str(), uuid: str(), npc: bool(), value: int(0, { min: 0, max: DT.maxBond }),
      was: new f.ArrayField(new f.NumberField({ integer: true })), dead: bool(), used: bool(), usedGround: bool(), grown: bool()
    })),
    ...tieFields()
  };
}

/* Навыки NPC по уровню: конскрипт — бонус ко всем, дуэлянт и ас — свои значения (layout). */
function npcSkills(sys, layout) {
  const conscript = sys.tier === "conscript";
  sys.skillTotal = Object.fromEntries(SKILL_KEYS.map(k => [k, conscript ? sys.bonus : layout[k] ?? 0]));
  sys.perkOn = Object.fromEntries(SKILL_KEYS.map(k => [k, 4]));
  sys.compOn = Object.fromEntries(SKILL_KEYS.map(k => [k, 1]));
}

/**
 * Опытная машина для «Испытателя»: шаблон Experimental Prototype, опытная или экспериментальная машина ангара,
 * Задел «Редкая машина» или «Доводка» на этот вылет. Флаг самолёта proto (true/false) решает вручную.
 */
export function isProto(plane, edges = []) {
  const flag = plane?.getFlag?.("thunderbolt-shtab", "proto");
  if (typeof flag === "boolean") return flag;
  if (edges.some(e => (e.kind === "rare" || e.kind === "tune") && !e.used)) return true;
  if (!plane) return false;
  const s = plane.system;
  return s.key === "prt" || s.base === "Experimental Prototype" || /опытн|эксперимент/i.test(s.cls ?? "");
}

/* Защита воздушной цели: Evasion (или Break!, если он выше) + Speed. */
function airDefense(sys, ev) {
  const evasion = Math.max(ev, sys.breakEv ?? -Infinity);
  return evasion + sys.speed;
}

/** Angle of Attack Limiter включён в этот ход этой машины (флаг aoa: бой, раунд, боец). */
function aoaActive(actor) {
  const f = actor?.getFlag?.(SYSTEM_ID, "aoa"), c = globalThis.game?.combat;
  return !!f && !!c && f.combat === c.id && f.round === c.round && c.combatant?.id === f.turn;
}

export class PilotData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      callsign: str(), lastName: str(), firstName: str(), patronymic: str(),
      rank: str(), flight: str(), squadron: str(), base: str(), birth: str(),
      archetype: str(),
      questions: new f.SchemaField({ callsign: str(), ground: str(), fear: str(), defy: str() }),
      dossier: new f.ArrayField(new f.SchemaField({ text: str(), struck: bool() }), { initial: [{ text: "", struck: false }] }),
      service: new f.SchemaField({
        sorties: int(0, { min: 0 }), ops: int(0, { min: 0 }), air: int(0, { min: 0 }), ground: int(0, { min: 0 }),
        eject: int(0, { min: 0 }), awards: str(), status: str("active"),
        // журнал вылетов: операция, дата, сбитые, катапульта (пишут «Итоги вылета»)
        log: new f.ArrayField(new f.SchemaField({ op: str(), date: str(), air: int(0), ground: int(0), eject: bool() }))
      }),
      bonusPoints: int(0),
      skills: skillSchema(),
      twist: bool(),
      wso: str(),
      insignia: str(),
      artwork: str(),                // портрет в полный рост; лицо — картинка актёра, самолёт — токен
      ...sortieFields(),
      ...downtimeFields(),
      notes: new f.HTMLField({ required: true, blank: true })
    };
  }

  get plane() { return this.parent.items.find(i => i.type === "plane") ?? null; }

  prepareDerivedData() {
    const actor = this.parent;
    const plane = this.plane;
    const ps = plane?.system.stats ?? { spd: 1, ev: 0, aa: 0, ag: 0, hp: 1, str: 0, gun: 0, hard: 0 };
    const propKeys = new Set((plane?.system.props ?? []).map(p => p.key));
    const triggers = actor.items.filter(i => i.type === "trigger");

    // эффекты триггеров: { цель: [{ name, value }] }
    const fx = {};
    const push = (target, name, value) => (fx[target] ??= []).push({ name, value });
    this.ammoBonus = {};
    this.perkOn = Object.fromEntries(SKILL_KEYS.map(k => [k, 4]));
    this.compOn = Object.fromEntries(SKILL_KEYS.map(k => [k, 1]));
    this.proto = isProto(plane, this.edges);
    const planeD4 = [];   // «Испытатель»: пороги d4 от машины, только в воздухе
    const groups = new Set();   // эффекты одной группы (Перчатка и Венок) не складываются
    for (const t of triggers) {
      const s = t.system;
      const chosen = [s.skill, s.skills > 1 ? s.skill2 : ""].filter(k => SKILL_KEYS.includes(k));
      for (const c of s.changes) {
        const n = s.factor(c, this);
        if (!n || !c.value) continue;
        if (c.group) { const g = `${c.group}:${c.target}`; if (groups.has(g)) continue; groups.add(g); }
        const v = c.value * n;
        if (c.target === "skill.chosen") chosen.forEach(k => push(`skill.${k}`, t.name, v));
        else if (c.target === "perk.chosen") chosen.forEach(k => { this.perkOn[k] = Math.min(this.perkOn[k], c.value); });
        else if (c.target === "comp.chosen") chosen.forEach(k => { this.compOn[k] = Math.max(this.compOn[k], c.value); });
        else if (c.target === "perk.all" || c.target === "comp.all") planeD4.push(c);
        else if (c.target === "ammo") { if (s.weapon) this.ammoBonus[s.weapon] = (this.ammoBonus[s.weapon] ?? 0) + v; }
        else push(c.target, t.name, v);
      }
    }
    // Заделы и последствия даунтайма действуют до конца следующего вылета
    for (const e of this.edges) {
      const label = DT.edges[e.kind] ?? "Задел";
      // Evasion и Max Speed без встречной цены не поднимаются (кроме Perk на чистом успехе)
      if (e.kind === "tune" && DT.tune[e.stat] && !(["ev", "spd"].includes(e.stat) && !e.minus && !e.minus2 && e.mode !== "perk")) {
        const [target, v] = DT.tune[e.stat];
        push(target, `Доводка`, v);
        for (const m of [e.minus, e.minus2]) if (m && DT.tuneMinus[m]) push(DT.tuneMinus[m][0], "Доводка: встречная цена", -1);
      } else if (e.kind === "ammo" && e.weapon) this.ammoBonus[e.weapon] = (this.ammoBonus[e.weapon] ?? 0) + 1;
      else if (e.kind === "fatigue") push("strainMax", label, -2);
      else if (e.kind === "trauma" && SKILL_KEYS.includes(e.skill)) push(`skill.${e.skill}`, label, -1);
    }
    // «Наследие проекта» погибшего товарища: +1 к параметру самолёта навсегда
    for (const l of actor?.getFlag?.(SYSTEM_ID, "legacy") ?? []) if (DT.tune[l.stat]) push(DT.tune[l.stat][0], `Наследие проекта: ${l.from}`, DT.tune[l.stat][1]);
    // на пределе: Complication на 1–2 во всех проверках
    this.edgeFly = this.nerves >= DT.maxNerves && this.onEdge === "fly";
    if (this.edgeFly) for (const k of SKILL_KEYS) this.compOn[k] = Math.max(this.compOn[k], 2);
    this.groundPerkOn = { ...this.perkOn };
    this.groundCompOn = { ...this.compOn };
    for (const c of planeD4) for (const k of SKILL_KEYS) {
      if (c.target === "perk.all") this.perkOn[k] = Math.min(this.perkOn[k], c.value);
      else this.compOn[k] = Math.max(this.compOn[k], c.value);
    }
    this.edgeCount = this.edges.filter(e => !DT.notEdges.includes(e.kind)).length;
    // «В строю» у союзника вплотную: + его ранги Lead к Evasion
    try {
      for (const uuid of actor.getFlag?.(SYSTEM_ID, "adjacent") ?? []) {
        const ally = fromUuidSync(uuid);
        // навык под Grit для пассивных способностей считается 0 (книга, стр. 23)
        if (ally?.items?.some(i => i.type === "trigger" && i.system.key === "inelement") && ally.system.skills?.lead && !ally.system.skillBlocked?.lead)
          push("evasion", `В строю: ${ally.name}`, ally.system.skills.lead);
      }
    } catch { /* союзник ещё не загружен: пересчёт на ready */ }
    // Angle of Attack Limiter (свойство машины): −2 Strain в свой ход, до конца хода +1 к Evasion, A-A, Aim, Dodge, Push
    this.aoa = propKeys.has("aoa") && aoaActive(actor);
    if (this.aoa) for (const k of ["aim", "dodge", "push"]) push(`skill.${k}`, "Angle of Attack Limiter", 1);
    const sum = target => (fx[target] ?? []).reduce((a, m) => a + m.value, 0);
    this.trigFx = fx;

    // навыки: база + триггеры (по навыку и на все броски)
    this.skillParts = Object.fromEntries(SKILL_KEYS.map(k => [k, [...(fx[`skill.${k}`] ?? []), ...(fx.allRolls ?? [])]]));
    this.skillMod = Object.fromEntries(SKILL_KEYS.map(k => [k, this.skillParts[k].reduce((a, m) => a + m.value, 0)]));
    this.skillTotal = Object.fromEntries(SKILL_KEYS.map(k => [k, this.skills[k] + this.skillMod[k]]));
    this.skillBlocked = Object.fromEntries(SKILL_KEYS.map(k => [k, this.markers.grit && this.markers.gritSkill === k]));
    this.pointsUsed = SKILL_KEYS.reduce((s, k) => s + this.skills[k], 0);
    this.pointsBudget = (this.archetype === "rookie" ? 3 : 6) + this.bonusPoints + sum("points");

    // самолёт с поправками триггеров и поломок
    // «Обходная цепь»: сломанная система снова работает, метка остаётся
    const bypass = actor.getFlag?.(SYSTEM_ID, "ctBypass");
    const broken = this.markers.structure && bypass !== this.markers.sys ? this.markers.sys : "";
    // РЭБ противника (ESM): система заглушена, пока машина в зоне глушения (флаг ставит и снимает ведущий)
    this.jam = actor.getFlag?.(SYSTEM_ID, "esm")?.sys ?? "";
    this.off = new Set([broken, this.jam].filter(Boolean));
    // разреженный воздух стратосферы: Max Speed +1, Evasion −1
    const thin = this.alt === "strat" ? 1 : 0;
    this.maxSpeed = Math.max(1, ps.spd + sum("maxSpeed") - (this.off.has("en") ? 1 : 0) + thin);
    this.hp.max = Math.max(1, ps.hp + sum("hpMax"));
    this.strain.max = this.off.has("fl") ? 0 : Math.max(0, (ps.str ?? 0) + sum("strainMax"));
    let ev = ps.ev + sum("evasion") - thin;
    if (propKeys.has("swing") && this.speed >= this.maxSpeed) ev += 1;
    if (propKeys.has("terrain") && this.alt === "low") ev += 1;
    // Angle of Attack Limiter: до конца своего хода +1 к Evasion и Air-to-Air (навыки — в skillParts выше)
    if (this.aoa) ev += 1;
    this.evasion = ev;
    this.defense = airDefense(this, ev);
    // Machine Gun Pod висит постоянно: Gun DMG +3 (и +1 Strafe в броске Guns), пока спецоружие не сломано Structure
    const mgp = this.off.has("sw") ? null : actor.items.find(i => i.type === "weapon" && i.system.key === "MGP" && i.system.ready);
    this.mgp = mgp?.id ?? "";
    this.aa = ps.aa + sum("aa") + (this.aoa ? 1 : 0); this.ag = ps.ag + sum("ag"); this.gun = ps.gun + sum("gun") + (mgp ? 3 : 0); this.hardpoints = ps.hard + sum("hardpoints");
    this.planeProps = propKeys;
    this.broken = broken;
    this.markerCount = ["grit", "structure", "doom"].filter(k => this.markers[k]).length;
  }
}

export class NpcData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      kind: str("air"), key: str(), grp: str(), grpName: str(), nato: str(), cls: str(), seats: int(1),
      tier: str("conscript"), bonus: int(0), squad: str(),
      skills: skillSchema(),
      stats: new f.SchemaField({ spd: int(3), ev: int(3), aa: nint(6), ag: nint(5), gun: nint(2), str: nint() }),
      ground: new f.SchemaField({ occ: int(4), ga: nint(), gg: nint(), gun: nint(), strafe: int(0) }),
      systems: new f.ArrayField(new f.SchemaField({
        name: str(), occ: int(4), hp: int(3), value: int(3), ga: nint(), gg: nint(), gun: nint(), note: str()
      })),
      props: named(), rules: named(),
      sig: new f.ArrayField(new f.StringField()),
      aceTriggers: new f.ArrayField(new f.StringField()),   // триггеры аса (TB.aceTriggers), Стрэйнджриал 9.5
      desc: str(), service: str(),
      insignia: str(), artwork: str(),
      // личное дело аса или дуэлянта; Немезида — личный враг одного из пилотов (nemesisOf — id актёра пилота)
      ...personFields(),
      nemesis: bool(), nemesisOf: str(), trackerImg: str("face"),   // дуэлянт в трекере боя: face — лицо, insignia — шильдик
      // сторона в бою и приоритетная цель (вкладка «Заметки AWACS»)
      side: str("enemy"), priority: bool(), task: str(),
      ...sortieFields(),
      notes: new f.HTMLField({ required: true, blank: true })
    };
  }

  /* Конскрипты, корабли-дуэлянты и летающие крепости: одна метка = Doom. Асы получают метки как пилоты, дуэлянты-самолёты — Structure и Doom (actor.mjs). */
  get fullMarkers() { return this.tier === "ace"; }

  prepareDerivedData() {
    // дуэлянты эскадрильи берут общую раскладку из настройки мира
    const layout = this.tier === "duelist" ? squadLayout(this.squad) ?? this.skills : this.skills;
    npcSkills(this, layout);
    this.squadPoints = squadPoints(layout);
    this.skillBlocked = Object.fromEntries(SKILL_KEYS.map(k => [k, this.markers.grit && this.markers.gritSkill === k]));
    this.markerCount = ["grit", "structure", "doom"].filter(k => this.markers[k]).length;
    this.broken = this.markers.structure ? this.markers.sys : "";
    this.jam = this.parent?.getFlag?.(SYSTEM_ID, "esm")?.sys ?? "";
    this.off = new Set([this.broken, this.jam].filter(Boolean));
    if (this.kind === "ship") {
      this.hp.max = this.systems.reduce((s, y) => s + y.hp, 0);
      this.hp.value = this.systems.reduce((s, y) => s + Math.max(0, y.value), 0);
      this.defense = null;
      this.maxSpeed = 0;
    } else if (this.kind === "ground") {
      this.defense = this.ground.occ;
      this.maxSpeed = 0;
    } else {
      // баллистическая ракета идёт по своей траектории: Defense 6 и в стратосфере
      const thin = this.alt === "strat" && !this.props.some(p => p.key === "ballistic") ? 1 : 0;
      this.maxSpeed = Math.max(1, this.stats.spd - (this.off.has("en") ? 1 : 0) + thin);
      // свойства из сводки, как у машин пилотов: крыло на Max Speed, огибание рельефа на Низкой, Angle of Attack Limiter
      const pk = new Set(this.props.map(p => p.key));
      // «Бортовые орудия»: ганшип кружит над целью, Max Speed в бою не выше 2
      if (pk.has("gunship")) this.maxSpeed = Math.min(this.maxSpeed, 2);
      this.aoa = pk.has("aoa") && aoaActive(this.parent);
      this.evasion = this.stats.ev - thin + (pk.has("swing") && this.speed >= this.maxSpeed ? 1 : 0) + (pk.has("terrain") && this.alt === "low" ? 1 : 0) + (this.aoa ? 1 : 0);
      this.defense = airDefense(this, this.evasion);
      this.aa = this.stats.aa === null ? null : this.stats.aa + (this.aoa ? 1 : 0); this.ag = this.stats.ag; this.gun = this.stats.gun;
      if (this.aoa) for (const k of ["aim", "dodge", "push"]) this.skillTotal[k] += 1;
      // ас: Strain машины + 5 (поле листа «Strain машины» переопределяет справочник)
      this.planeStrain = this.tier === "ace" ? acePlaneStrain(this) : null;
      // сломанные закрылки (Structure: Flaps) у аса, как у пилота: Strain 0
      this.strain.max = this.tier === "ace" && !this.off.has("fl") ? this.planeStrain + ACE_STRAIN_EXTRA : 0;
    }
    // триггеры пилотов против Немезиды до конца вылета: «Знаю эту машину» (−1 к Evasion, Max Speed или A-A), «Я тоже в это верил» (Complication 1–2)
    const nf = this.nemesis ? this.parent?.getFlag?.(SYSTEM_ID, "nemFx") ?? {} : {};
    if (this.kind === "air" && nf.flaw === "ev") { this.evasion -= 1; this.defense = airDefense(this, this.evasion); }
    if (this.kind === "air" && nf.flaw === "spd") this.maxSpeed = Math.max(1, this.maxSpeed - 1);
    if (this.kind === "air" && nf.flaw === "aa" && this.aa !== null) this.aa -= 1;
    if (nf.comp2) for (const k of SKILL_KEYS) this.compOn[k] = Math.max(this.compOn[k], 2);
  }
}

/* Персонаж на земле: штаб, техники, гражданские, близкие и родственники пилотов. Самолёта, атак и урона нет;
   навыки по уровню, как у NPC. role — кто это (TB.staffRoles), relatedTo — id пилота, чей это близкий, relation — кем приходится. */
export class StaffData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      role: str("staff"), position: str(),     // должность или занятие: начальник штаба, старший техник, учительница
      relatedTo: str(), relation: str(),
      tier: str("conscript"), bonus: int(0), skills: skillSchema(),
      side: str("ally"), insignia: str(), artwork: str(),
      ...personFields(),
      strain: new f.SchemaField({ value: int(0), max: int(0) }),
      notes: new f.HTMLField({ required: true, blank: true })
    };
  }

  prepareDerivedData() {
    npcSkills(this, this.skills);
    this.skillBlocked = Object.fromEntries(SKILL_KEYS.map(k => [k, false]));
  }
}

export class PlaneData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      key: str(), nato: str(), cls: str(), cat: str(), catName: str(), tier: int(0), tierName: str(), base: str(),
      seats: int(1), carrier: bool(), est: bool(),
      stats: new f.SchemaField({
        spd: int(3), ev: int(3), aa: int(6), ag: int(5), hp: int(3), str: int(10), gun: int(2), hard: int(1)
      }),
      props: named(),
      sig: new f.ArrayField(new f.StringField()),
      ac5: new f.ObjectField({ required: false, nullable: true, initial: null }),
      desc: str(), service: str(),
      // роль машины и фирменный приём (Стрэйнджриал 8.5–8.6); пусто — по ключу машины (TB.roleOf, TB.moveOf)
      role: str(), move: str()
    };
  }
}

export class WeaponData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      key: str(), group: str(), kind: str("book"), target: str("air"),
      ammo: new f.SchemaField({ value: nint(4), max: nint(4) }),
      dmg: str("5"), aa: nint(), ag: nint(), aim: nint(), dep: nint(),
      fx: str(),
      range: nint()   // null: по ключу из TB.weaponRange или как обычная ракета
    };
  }
  get unlimited() { return this.ammo.max === null; }
  /** Выведено из строя до конца вылета («Форсированный выстрел»). */
  get offline() { return !!this.parent?.getFlag?.(SYSTEM_ID, "off"); }
  /** Можно стрелять: не выведено из строя и есть боезапас. */
  get ready() { return !this.offline && (this.unlimited || (this.ammo.value ?? 0) > 0); }
  /** Дальность в зонах: 0 своя, 1 соседние, 2 обычная ракета, 99 вся зона операции. */
  /** Черта спецоружия (Стрэйнджриал 8.2): { name, text } или null. */
  get trait() { return TB.weaponTraits[this.key] ?? null; }
  get reach() { return this.range ?? TB.weaponRange[this.key] ?? (this.target === "gun" ? TB.range.guns : TB.range.missile); }
}

export class TriggerData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      key: str(), archetype: str(), en: str(),
      types: new f.ArrayField(new f.StringField()),
      text: str(), skills: int(0), mod: int(0), slot: bool(),
      skill: str(), skill2: str(),
      used: bool(),
      active: bool(), stack: int(0, { min: 0 }), weapon: str(),
      // null: встроенные эффекты книжного триггера по ключу (TB.triggerEffects), массив: свой список
      effects: new f.ArrayField(new f.SchemaField({ target: str("hpMax"), value: int(1), when: str("always") }),
        { required: true, nullable: true, initial: null })
    };
  }

  /** Эффекты, которые сейчас действуют на чарник. */
  get changes() { return this.effects ?? TB.triggerEffects[this.key] ?? []; }
  get hasToggle() { return this.changes.some(c => c.when === "toggle" || c.when === "twisttoggle"); }
  get hasStack() { return this.changes.some(c => c.when === "stack"); }
  get needsWeapon() { return this.changes.some(c => c.target === "ammo"); }

  /** Множитель эффекта: 0, если условие не выполнено. */
  factor(change, actorSystem) {
    switch (change.when) {
      case "twist": return actorSystem.twist ? 1 : 0;
      case "toggle": return this.active ? 1 : 0;
      // против Немезиды: в атаке и защите по ней (nemesis.mjs), на весь лист не действует
      case "nemesis": return 0;
      // боевые триггеры: Поединок и условия атаки считаются в самой атаке (combat-triggers.mjs)
      case "duel": case "attack": return 0;
      case "twisttoggle": return this.active && actorSystem.twist ? 1 : 0;
      case "stack": return this.stack;
      case "proto": return actorSystem.proto ? 1 : 0;
      case "serial": return actorSystem.proto ? 0 : 1;
      default: return 1;
    }
  }
}
