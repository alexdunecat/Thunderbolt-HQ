/* Предупреждение об облучении: значок захвата на токене цели и сигнал её владельцу.
   Значок видят ведущий, владелец цели и тот, кто держит захват. Сигнал «Ракета!» молчит, если у цели сломан MAWS. */
import { SYSTEM_ID } from "./config.mjs";
import { resolveActor, layoutChanged } from "./utils.mjs";
import { sideOf } from "./scene.mjs";

/** У игрока есть пилот с «Общей частотой». */
const sharedFreq = () => (game.actors ?? []).some(a => a.type === "pilot" && a.isOwner && a.items.some(i => i.type === "trigger" && i.system.key === "sharedfreq"));

export function registerRwr() {
  Hooks.on("refreshToken", (t, flags) => { if (layoutChanged(flags)) drawBadge(t); });
  Hooks.on("canvasReady", () => refreshAll());
  // у NPC без связи с актёром захват живёт в дельте токена: её обновление приходит отдельным хуком
  for (const ev of ["updateActor", "updateActorDelta", "updateToken", "createToken", "deleteToken", "targetToken"]) Hooks.on(ev, refreshSoon);
  Hooks.on("createChatMessage", (message, options) => { if (!options?.tbUndo) alertOwner(message); });
}

let timer = null;
function refreshSoon() {
  clearTimeout(timer);
  timer = setTimeout(refreshAll, 60);
}
function refreshAll() {
  if (!canvas?.ready) return;
  // один проход: кто кого держит и «Общая частота» — один раз на всю сцену, а не на каждый токен
  const by = new Map();
  for (const t of canvas.tokens.placeables) {
    const u = t.actor?.system?.lockUuid;
    if (u) { if (!by.has(u)) by.set(u, []); by.get(u).push(t); }
  }
  const ctx = { by, freq: !game.user.isGM && sharedFreq() };
  for (const t of canvas.tokens.placeables) drawBadge(t, ctx);
}

/** Токены, которые держат этот токен на захвате. */
export function lockersOf(token) {
  const uuid = token.actor?.uuid;
  if (!uuid) return [];
  return canvas.tokens.placeables.filter(t => t !== token && t.actor?.system?.lockUuid === uuid);
}

function drawBadge(token, ctx = null) {
  // «Общая частота»: пилот игрока видит захваты на всех союзниках
  const freq = !game.user.isGM && ["player", "ally"].includes(sideOf(token.actor)) && (ctx ? ctx.freq : sharedFreq());
  const lockers = ctx ? (ctx.by.get(token.actor?.uuid) ?? []).filter(t => t !== token) : lockersOf(token);
  const seen = lockers.filter(l => game.user.isGM || token.actor?.isOwner || l.actor?.isOwner || freq);
  let g = token.tbLockBadge;
  if (!seen.length) {
    if (g && !g.destroyed) g.destroy({ children: true });
    token.tbLockBadge = null;
    return;
  }
  // значок уже такой же (тот же размер и число захватов): не перерисовывать
  const sig = `${seen.length}|${token.w}|${token.h}`;
  if (g && !g.destroyed && g.tbSig === sig) return;
  if (!g || g.destroyed) {
    g = token.tbLockBadge = token.addChild(new PIXI.Graphics());
    g.eventMode = "none";
  }
  g.tbSig = sig;
  // красное кольцо с перекрестием в левом верхнем углу токена, рядом число захватов
  const r = Math.max(7, Math.min(token.w, token.h) * 0.16);
  g.clear();
  g.lineStyle(Math.max(2, r * 0.22), 0xff3b2f, 1).beginFill(0x1e0a08, 0.75).drawCircle(0, 0, r).endFill();
  g.moveTo(-r * 1.35, 0).lineTo(-r * 0.45, 0).moveTo(r * 0.45, 0).lineTo(r * 1.35, 0)
    .moveTo(0, -r * 1.35).lineTo(0, -r * 0.45).moveTo(0, r * 0.45).lineTo(0, r * 1.35);
  g.position.set(r * 0.9, r * 0.9);
  g.removeChildren().forEach(c => c.destroy());
  if (seen.length > 1) {
    const txt = new PIXI.Text(String(seen.length), { fontFamily: "monospace", fontSize: Math.round(r * 1.3), fontWeight: "bold", fill: 0xffffff, stroke: 0x000000, strokeThickness: 3 });
    txt.anchor.set(0, 0.5);
    txt.position.set(r * 1.2, r * 0.9);
    g.addChild(txt);
  }
}

/** Сигнал владельцу цели: захват (флаг rwr на карточке Lock On!) или пуск по нему (card.maws).
    С субтитрами AWACS текст говорит радио; звук захвата и пуска — сигналы кабины (sounds.mjs). */
function alertOwner(message) {
  if (game.user.isGM) return;
  const rwr = message.getFlag(SYSTEM_ID, "rwr");
  const card = message.getFlag(SYSTEM_ID, "card");
  const uuid = rwr?.target ?? (card?.maws ? card.targetUuid : null);
  const target = uuid ? resolveActor(uuid) : null;
  if (!target?.isOwner) return;
  let radio = true;
  try { radio = game.settings.get(SYSTEM_ID, "radioSubtitles"); } catch {}
  if (!radio) {
    if (rwr) ui.notifications.warn(`Облучение! ${rwr.from} держит «${target.name}» на захвате.`);
    else ui.notifications.error(`Ракета! ${card.actorName}: ${card.label} по «${target.name}». Самое время для Break!`);
  }
}
